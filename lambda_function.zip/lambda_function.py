import json

def lambda_handler(event, context):
    print("A File has been uploaded to s3")
    return "A File has been uploaded to s3"

